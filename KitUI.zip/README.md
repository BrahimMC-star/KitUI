My own version of a Kit System, no plugin needed to run it, just put it in and enjoy the fruits of my labor!
**Important Note:** Carefully read the `config.yml` file, as important details are contained within it. Failure to read this file may result in server crashes.
Enjoy the plugin!