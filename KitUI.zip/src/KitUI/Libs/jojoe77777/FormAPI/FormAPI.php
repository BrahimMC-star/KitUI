<?php

declare(strict_types = 1);

namespace KitUI\Libs\jojoe77777\FormAPI;

use pocketmine\plugin\PluginBase;

class FormAPI extends PluginBase{

}
